function donate(element) {
    element.remove()
}
var count1 = 3;
var count1Element = document.querySelector("#count1");

console.log(count1Element);

function add1a() {
    count1++;
    count1Element.innerText = count1 + " petting(s)";
    console.log(count1);
}
function showAlert(select) {
    if(select.options[select.selectedIndex].value == "Cats") {
    alert("You are looking for a: Cat");
    }   
    if(select.options[select.selectedIndex].value == "Dogs") {
        alert("You are looking for a: Dog")
    }
}
var count2 = 5;
var count2Element = document.querySelector("#count2");

console.log(count2Element);

function add1b() {
    count2++;
    count2Element.innerText = count2 + " petting(s)";
    console.log(count2);
}
var count3 = 8;
var count3Element = document.querySelector("#count3");

console.log(count3Element);

function add1c() {
    count3++;
    count3Element.innerText = count3 + " petting(s)";
    console.log(count3);
}